using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Windows.Forms;

namespace AdvListBox
{
    public partial class NewListBox : ListBox
    {
        int columnIndex = -1;

        public NewListBox()
        {
            InitializeComponent();
        }

        public NewListBox(IContainer container)
        {
            container.Add(this);

            InitializeComponent();
        }

        /// <summary>
        /// ColumnIndex of DataGridView that is going to assign ListBox.
        /// </summary>
        [
         Browsable(true), Category("Binding Column"), 
         Description("To assign this ListBox to paticular column of DataGridView")
        ]
        public int ColumnIndex
        {
            get
            { return columnIndex; }

            set
            { columnIndex = value; }
        }
    }
}
