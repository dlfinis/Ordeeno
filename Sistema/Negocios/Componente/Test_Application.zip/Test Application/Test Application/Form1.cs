using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Test_Application
{
    public partial class Form1 : Form
    {
        int rowIndex, columnIndex;

        public Form1()
        {
            InitializeComponent();

            //EventHandler for ListBox that added to the DataGridView.
            this.newDataGridView1.ListBoxCollection[0].DoubleClick += 
                new EventHandler(ListBox1_DoubleClick);
        }

        /// <summary>
        /// When ListBox is double clicked, called this method.
        /// Add selecte item of ListBox into appropiate cell of the DataGridView.
        /// After then hide ListBox.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void ListBox1_DoubleClick(object sender, EventArgs e)
        {
            this.newDataGridView1[columnIndex, rowIndex].Value = 
                this.newDataGridView1.ListBoxCollection[0].SelectedItem.ToString();

            this.newDataGridView1.ListBoxCollection[0].Visible = false;
        }

        /// <summary>
        /// Get row index and column index of selected cell of the DataGridView.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void newDataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            rowIndex = e.RowIndex;
            columnIndex = e.ColumnIndex;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Add new row to the DataGridView.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAddRow_Click(object sender, EventArgs e)
        {
            this.newDataGridView1.Rows.Add();
        }
    }
}