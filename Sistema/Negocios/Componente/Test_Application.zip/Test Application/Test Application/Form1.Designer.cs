namespace Test_Application
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnAddRow = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.newDataGridView1 = new AdvDataGridView.NewDataGridView(this.components);
            this.newListBox12 = new AdvListBox.NewListBox(this.components);
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.newDataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAddRow
            // 
            this.btnAddRow.Location = new System.Drawing.Point(12, 37);
            this.btnAddRow.Name = "btnAddRow";
            this.btnAddRow.Size = new System.Drawing.Size(75, 23);
            this.btnAddRow.TabIndex = 0;
            this.btnAddRow.Text = "Add Row";
            this.btnAddRow.UseVisualStyleBackColor = true;
            this.btnAddRow.Click += new System.EventHandler(this.btnAddRow_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(342, 222);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // newDataGridView1
            // 
            this.newDataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.newDataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3});
            this.newDataGridView1.ListBoxCollection = new AdvListBox.NewListBox[] {
        this.newListBox12};
            this.newDataGridView1.Location = new System.Drawing.Point(12, 66);
            this.newDataGridView1.Name = "newDataGridView1";
            this.newDataGridView1.Size = new System.Drawing.Size(405, 150);
            this.newDataGridView1.TabIndex = 2;
            this.newDataGridView1.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.newDataGridView1_CellEnter);
            // 
            // newListBox12
            // 
            this.newListBox12.ColumnIndex = 1;
            this.newListBox12.FormattingEnabled = true;
            this.newListBox12.Items.AddRange(new object[] {
            "Sri Lanka",
            "India",
            "Australia",
            "USA",
            "England"});
            this.newListBox12.Location = new System.Drawing.Point(0, 0);
            this.newListBox12.Name = "newListBox12";
            this.newListBox12.Size = new System.Drawing.Size(120, 30);
            this.newListBox12.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.Frozen = true;
            this.Column1.HeaderText = "Name";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.Frozen = true;
            this.Column2.HeaderText = "Country";
            this.Column2.Name = "Column2";
            this.Column2.Width = 150;
            // 
            // Column3
            // 
            this.Column3.Frozen = true;
            this.Column3.HeaderText = "Phone";
            this.Column3.Name = "Column3";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(432, 258);
            this.Controls.Add(this.newDataGridView1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnAddRow);
            this.Name = "Form1";
            this.Text = "DataGridView with ListBox";
            ((System.ComponentModel.ISupportInitialize)(this.newDataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAddRow;
        private System.Windows.Forms.Button btnClose;
        private AdvDataGridView.NewDataGridView newDataGridView1;
        public AdvListBox.NewListBox newListBox12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
    }
}